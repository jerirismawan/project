/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.storageing;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTreeView;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author vb080719
 */
public class Form_pengindeksan_dokumenController implements Initializable {

    @FXML
    private AnchorPane formpengindeksandokumen;
    @FXML
    private JFXButton btnindeks;
    @FXML
    private JFXButton simpanindeks;
    @FXML
    private JFXButton id_pengdok;
    @FXML
    private JFXButton id_lengdok;
    @FXML
    private JFXButton loggout;
    @FXML
    private AnchorPane idlengkapidok;
    @FXML
    private JFXTextField Keywords;
    @FXML
    private JFXTextField Title;
    @FXML
    private JFXTextField Author;

    @FXML
    private JFXTextField NPM;
    @FXML
    private JFXTextField Year;
//fulltext   
    @FXML
    private JFXTextField Status;
    @FXML
    private JFXTextField Tags;
    
    @FXML
    private JFXTextField IDDoc;
    @FXML 
    private JFXTextField Month;
    @FXML
    private TextField tf_judul;
    @FXML
    private JFXTreeView<?> FullText;
  

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btn_indeks(ActionEvent event) {
    }

    @FXML
    private void btn_simpanindeks(ActionEvent event) {
    }


    @FXML
    private void btn_pengdok(ActionEvent event) {
    idlengkapidok.getChildren().clear();
            Node [] nodes = new  Node[15];
            for(int i = 0; i<10; i++){
                try {
                    nodes[i] = (Node)FXMLLoader.load(getClass().getResource("/fxml/fPengelolaan_dokumen.fxml"));
                    idlengkapidok.getChildren().add(nodes[i]);   
                } catch (IOException ex) {
                    Logger.getLogger(Form_pengindeksan_dokumenController.class.getName()).log(Level.SEVERE, null, ex);
                
                    }           
                
    }
    }    
    

    @FXML
    private void btn_lengdok(ActionEvent event) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Pesan");
                alert.setHeaderText(null);
                alert.setContentText("Anda Berada di form lengkapi dokumen");
                alert.showAndWait();
    }

    @FXML
    private void btn_keluar(ActionEvent event) {
         idlengkapidok.getChildren().clear();
            Node [] nodes = new  Node[15];
            for(int i = 0; i<10; i++){
                try {
                    nodes[i] = (Node)FXMLLoader.load(getClass().getResource("/fxml/fLogin.fxml"));
                    idlengkapidok.getChildren().add(nodes[i]);   
                } catch (IOException ex) {
                    Logger.getLogger(Form_pengindeksan_dokumenController.class.getName()).log(Level.SEVERE, null, ex);
                
                    }           
                
    }
    }
    
    
}


package com.mycompany.storageing;

import aplikasi_penyimpanan.config.config;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTreeView;
import com.mycompany.util.ConnectionUtil;
import module.User;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger; 
import java.util.Scanner;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javax.swing.table.DefaultTableModel;
import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import com.mycompany.storageing.Elastic;

public class Form_pengelolaan_dokumenController implements Initializable {
    @FXML
    private AnchorPane formpengelolaandokumen;
    @FXML
    private AnchorPane pengdok;
    @FXML
    private JFXButton btnPengDok;
    @FXML
    private JFXButton btnIndexDok;
    @FXML
    private JFXButton logout;
    @FXML
    private JFXButton browsedok;
    @FXML
    private JFXButton hapus_dok;
    @FXML
    private JFXButton simpan_dok;
    @FXML
    private JFXListView listvieww;
    @FXML
    private JFXButton reset_akun;
    public JFXButton btn_reset;
    public JFXTextField txt_judul;
    public JFXTextField txt_tahun;
    public JFXTextField txt_author;
    private TextField tf_file;
    private JFXTextField txt_npm;
    private JFXTextField txt_nama;
    private JFXTextField txt_pass;
    @FXML
    private Button hapusakun;
    @FXML
    private Button idbatalreset;
    private JFXTextField txt_email;
    private JFXTextField txt_tlp;
    private JFXTextField txt_username;
    private TextField txt_cat;
    @FXML
    private TextField txt_masukan_user;
    @FXML
    private AnchorPane idinput;
    @FXML
    private VBox idvxbox;
    @FXML
    private JFXTreeView<?> txt_file;
    @FXML
    private TextField txtcaridok;
    @FXML
    private Button idcaridok;
    @FXML
    private JFXTextField txt_author1;
    private JFXTextField txt_judul_skrip;
    @FXML
    private Button hapusdok;
    @FXML
    private Button idbatalhapusdok;
    private JFXTextField txt_tahunterbit;
    @FXML
    private JFXTextField tahun;
    @FXML
    private JFXTextField judul;
    @FXML
    private Pane pane_reset;
    @FXML
    private Pane pane_hapusdok;
    @FXML
    private JFXTextField tAuthor;
    @FXML
    private JFXTextField tTitle;
    @FXML
    private JFXTextField tYear;
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     
    }    
   
    @FXML
    private void handleButtonClicks(MouseEvent event) {
    }

    private void btnPengDok(ActionEvent event) {
         Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("pesan");
                alert.setHeaderText(null);
                alert.setContentText("Anda berada di form pengelolaan dokumen!");
                alert.showAndWait();   
               
    }

    @FXML
    private void btn_pengindeks(ActionEvent event) {
         pengdok.getChildren().clear();
            Node [] nodes = new  Node[15];
            for(int i = 0; i<10; i++){
                try {
                    nodes[i] = (Node)FXMLLoader.load(getClass().getResource("/fxml/fLengkapi_dok.fxml"));
                    pengdok.getChildren().add(nodes[i]);   
                } catch (IOException ex) {
                    Logger.getLogger(Form_pengelolaan_dokumenController.class.getName()).log(Level.SEVERE, null, ex);
                
                    }           
                
    }
    }

    @FXML
    private void btn_logout(ActionEvent event) {
           pengdok.getChildren().clear();
            Node [] nodes = new  Node[15];
            for(int i = 0; i<10; i++){
                try {
                    nodes[i] = (Node)FXMLLoader.load(getClass().getResource("/fxml/fLogin.fxml"));
                    pengdok.getChildren().add(nodes[i]);   
                } catch (IOException ex) {
                    Logger.getLogger(Form_pengelolaan_dokumenController.class.getName()).log(Level.SEVERE, null, ex);
                
                }}
    }

    @FXML
    private void btn_browse_dok(ActionEvent event) {
        FileChooser fc = new FileChooser();
         fc.getExtensionFilters().addAll(
        new FileChooser.ExtensionFilter("PDF Files", "*.pdf"));
          File selectedFile = fc.showOpenDialog(null);  
     
         
      
        if (selectedFile != null){
            listvieww.getItems().add(selectedFile.getAbsolutePath());
              String dir = selectedFile.getAbsolutePath();
    listvieww.getItems().add(dir);
    tf_file.setText(dir);
    
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle("Pencarian");
     alert.setHeaderText(null);
                 alert.setContentText(" file yang anda cari adalah :"+"'"+dir+",");
          
                alert.showAndWait();
        } else {
            System.out.println("file is not valid");
        }
    } 

    @FXML
    private void btn_hapus_dok(ActionEvent event) {
        pane_hapusdok.setVisible(true);
        idinput.setDisable(true);
        idvxbox.setDisable(true);
        
    }
    @FXML
    public void btn_simpan_dok(ActionEvent event) {
      ObservableList pdf = listvieww.getItems();        
        String penulis = tAuthor.getText();
        String judul = tTitle.getText();
        int tahun;
        tahun = Integer.valueOf(tYear.getText());
        
        
        ObjectMapper mapper = new ObjectMapper();
        User user = createDummyUser(pdf,penulis,judul, tahun);
        
        try {
            String jsonInString = mapper.writeValueAsString(user);
            jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(user);
            
                        
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Simpan data?");
            alert.setHeaderText(null);
            alert.setContentText(jsonInString);
            alert.showAndWait();
                 
	} catch (JsonGenerationException e) {
            e.printStackTrace();
	} catch (JsonMappingException e) {
            e.printStackTrace();
	} catch (IOException e) {
	e.printStackTrace();
	} 
    } 
    
    private User createDummyUser(ObservableList pdf, String penulis, String judul, int tahun) {
        User user = new User();
        user.setFile(pdf);
	user.setAuthor(penulis);
        user.setTitle(judul);
	user.setYear(tahun); 
	return user; 
    } 
    
    @FXML
    private void btn_hapusakun(ActionEvent event) {
    String user ="";
    String sql = "";
    ResultSet res= null;
    
    user = txt_masukan_user.getText();
        try {    
             java.sql.Connection conn=(Connection)config.configDB();
             java.sql.PreparedStatement pst;
             sql = "select * from tabel_user where username='"+user+"'";
             pst=conn.prepareStatement(sql);
             res = pst.executeQuery();
              if(!res.next()){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setContentText("Username tidak ditemukan!!!");
                alert.setTitle("Gagal");
                alert.showAndWait();
              }else{
                sql = "delete from tabel_user where username='"+user+"'";
                pst=conn.prepareStatement(sql);
                pst.execute();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("pesan");
                alert.setHeaderText(null);
                alert.setContentText("Akun " +user+" berhasil Reset !");
                alert.showAndWait();
                pane_reset.setVisible(false);
                idinput.setDisable(false);
                idvxbox.setDisable(false);
                txt_masukan_user.setText("");
          }
        } catch (Exception h) {
          
        }
        
    }

    
    @FXML
    private void btl_batalreset(ActionEvent event) {
        pane_reset.setVisible(false);
        idinput.setDisable(false);
        idvxbox.setDisable(false);
        
    }
        
    @FXML
    public void btn_reset(ActionEvent event) {
        pane_reset.setVisible(true);
        idinput.setDisable(true);
        idvxbox.setDisable(true);
     }

    @FXML
    private void btn_carijudul(ActionEvent event) {
        mCariDokumen();
    }
    private void mCariDokumen(){
    String name = "implementasi elasticsearch karya ilmiah";{
     if(name.equalsIgnoreCase(txtcaridok.getText())) {   
                
                 Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Pesan");
                alert.setHeaderText(null);
                alert.setContentText("validasi Data");
                alert.showAndWait();
                 alert.setTitle("Pesan");
                alert.setHeaderText(null);
                alert.setContentText("Verifikasi Data");
                alert.showAndWait();
      txt_author1.setText("jeri rismawan"); 
   
      judul.setText("Implementasi Elasticsearch Pada Repositori karya ilmiah UNIBBA");
    
      tahun.setText("2001");
    
       }else{
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Pesan");
                alert.setHeaderText(null);
                alert.setContentText("validasi Data");
                alert.showAndWait();
                 alert.setTitle("Pesan");
                alert.setHeaderText(null);
                alert.setContentText("Verifikasi Data");
                alert.showAndWait();     
                   alert.setTitle("Pesan");
                alert.setHeaderText(null);
                alert.setContentText(" judul skripsi tidak ditemukan");
                alert.showAndWait(); 
            }
}
}
   @FXML
    private void btn_hapusdok(ActionEvent event) {
        mHapusDokumen();  
      
    }
    private void mHapusDokumen(){
        String nama =  txt_author1.getText();
        String judul =  txt_judul.getText();
        String Tahun =  tahun.getText();
        
                pane_hapusdok.setVisible(false);
                idinput.setDisable(false);
                idvxbox.setDisable(false);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle(" Dokumen Berhasil dihapus" );
                alert.setHeaderText(null);
                 alert.setContentText("Author :"+""+nama+","
                         + "Judul :"+""+judul+","
                         +"Tahhun terbit :"+""+Tahun +".");
                         
     
    }

    @FXML
    private void btn_batalhapusdok(ActionEvent event) {
        pane_hapusdok.setVisible(false);
          idinput.setDisable(false);
        idvxbox.setDisable(false);
    }
 
    @FXML
    private void btn_pengdok(ActionEvent event) {
    }
 
     }
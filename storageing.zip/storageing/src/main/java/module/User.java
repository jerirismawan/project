/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;
import java.util.List;
import javafx.collections.ObservableList;
/**
 *
 * @author vb080719
 */
public class User {
    private ObservableList file;
    private String author;
    private String title ;
    private Integer year;
   
    

    public ObservableList getFile() {
        return file;
    }
    public void setFile(ObservableList file) {
        this.file= file;    
            }  
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
      this.title = title;  
    }
     public Integer getYear() {
        return year ;
    }
    public void setYear(Integer year) {
      this.year = year;  
    }
    

}

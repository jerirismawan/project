/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author vb080719
 */
public class FDaftar_akunController implements Initializable {

    @FXML
    private JFXPasswordField tfpassword;
    @FXML
    private JFXTextField tfuser;
    @FXML
    private JFXButton buttonLogin;
    @FXML
    private JFXButton logindaftarakun;
    @FXML
    private AnchorPane iddaftarakun;
    @FXML
    private Button simpanakun;
    @FXML
    private Button batalakun;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btn_login(ActionEvent event) {
    }

    @FXML
    private void btn_daftarakun(ActionEvent event) {
    }

    @FXML
    private void btn_simpanakun(ActionEvent event) {
    }

    @FXML
    private void btn_batalakun(ActionEvent event) {
    }
    
}
